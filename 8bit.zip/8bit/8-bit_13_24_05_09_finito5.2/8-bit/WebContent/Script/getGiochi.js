$(document).ready(function(){
	
  		$.ajax({
  			type:"get",
  			url:"getGiochi",
  			success:function(result){
  				
  			}
  		})
  	})