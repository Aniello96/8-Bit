$(document).ready(function(){
	
  		$.ajax({
  			type:"get",
  			url:"GetItemsCollocamento",
  			success:function(result){
  				
  			}
  		})
  	})