-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: 8bit
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `collocamento`
--

DROP TABLE IF EXISTS `collocamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collocamento` (
  `id_gioco` varchar(45) NOT NULL,
  `id_fattura` int(10) NOT NULL,
  `pezzi` int(10) DEFAULT NULL,
  `prezzo_unitario` double DEFAULT NULL,
  PRIMARY KEY (`id_gioco`,`id_fattura`),
  KEY `id_fattura_idx` (`id_fattura`),
  CONSTRAINT `id_fattura` FOREIGN KEY (`id_fattura`) REFERENCES `fattura` (`id_fattura`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `id_gioco` FOREIGN KEY (`id_gioco`) REFERENCES `gioco` (`titolo_gioco`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collocamento`
--

LOCK TABLES `collocamento` WRITE;
/*!40000 ALTER TABLE `collocamento` DISABLE KEYS */;
INSERT INTO `collocamento` VALUES ('Donkey Kong',63,1,3),('Galaga',64,2,2.75),('Galaga',67,3,2.75),('Galaga',68,3,2.75),('Mario Kart 64',64,1,5.5),('Metal Slug',65,3,3.5),('Pac Man',62,2,5),('Rayman 2',65,2,2.45),('Super Metroid',66,2,2.45),('Super Smash Bros',66,1,3);
/*!40000 ALTER TABLE `collocamento` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-05 13:31:14
